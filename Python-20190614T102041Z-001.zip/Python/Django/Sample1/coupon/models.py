# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Coupon(models.Model):
    percent_off = models.PositiveIntegerField(default=0, null=True)
    amount_off = models.FloatField(default=0, null=True)
    duration = models.CharField(max_length=2, default='once', choices=(
                                ('1', 'once'),
                                ('2', 'monthly'),
                                ('3', 'forever')
                            ))
    code = models.CharField(unique=True, max_length = 50)
    description = models.TextField()
    max_redemptions = models.PositiveIntegerField(default=0, null=True)
    redeem_by = models.DateTimeField(null=True)
    publish = models.BooleanField(default=False)
    created_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_on"]
