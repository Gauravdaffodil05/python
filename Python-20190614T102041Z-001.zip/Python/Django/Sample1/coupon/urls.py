from django.conf.urls import url
from .views import CouponList, CouponCreate, CouponDetail, CouponState

urlpatterns = [
    url(r'^$', CouponList.as_view(), name='coupon'),
    url(r'^new/$', CouponCreate.as_view(), name='create-coupon'),
    url(r'^detail/(?P<pk>\d+)/$', CouponDetail.as_view(), name='coupon-detail'),
    url(r'^state/(?P<pk>\d+)$', CouponState.as_view(), name='coupon-state'),
]
