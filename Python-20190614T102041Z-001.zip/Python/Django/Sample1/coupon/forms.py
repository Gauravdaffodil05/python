from django.forms import ModelForm
from django import forms
from .models import Coupon

class CouponForms(ModelForm):
    field_order = ['percent_off', 'amount_off', 'duration', 'duration_month']

    def clean(self):
        cleaned_data = super(CouponForms, self).clean()
        percent_off  = cleaned_data.get('percent_off')
        amount_off  = cleaned_data.get('amount_off')

        # percent_off or amount_off any one field value must be passed.
        if percent_off is None and amount_off is None:
            raise forms.ValidationError(
                "Please provide a value in percent_off or in amount_off field"
            )
        elif percent_off and amount_off:
            raise forms.ValidationError(
                "Please provide a value in percent_off or in amount_off field at a time"
            )

    class Meta:
        model = Coupon
        fields = '__all__'
