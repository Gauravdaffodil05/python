# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, reverse
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse_lazy
from django.db.models import Case, When, Value

from django.views import View
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView

from .models import Coupon
from .forms import CouponForms

class CouponList(ListView):
    """
    Render the list of coupons with pagination.
    """
    model = Coupon
    paginate_by = 10
    template_name = "admin/coupon/list.html"

class CouponCreate(CreateView):
    """
    Create a new coupon.
    """
    form_class = CouponForms
    template_name = "admin/coupon/form.html"
    success_url = reverse_lazy('coupon')


class CouponDetail(DetailView):
    """
    Render the detail of coupon.
    """
    model = Coupon
    template_name = "admin/coupon/detail.html"


class CouponState(View):
    def get(self, request, pk):
        """
        get method will update the present state of coupon.
        """
        Coupon.objects.filter(pk=pk).update(publish = Case(
            When(publish=True, then=Value(False)),
            default=Value(True)
        ))
        return HttpResponseRedirect(reverse('coupon'))
