from django import template
register = template.Library()

@register.filter(name='addcss')
def addcss(field, css):
    """
    Filter to add classes on HTML element
    """
    return field.as_widget(attrs={"class":css})
